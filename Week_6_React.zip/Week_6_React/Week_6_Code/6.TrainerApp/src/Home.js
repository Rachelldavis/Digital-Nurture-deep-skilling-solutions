// src/Home.js
import React from "react";

const Home = () => {
  return (
    <div>
      <h2>Welcome to My Acdemy trainers page</h2>    </div>
  );
};

export default Home;
