import React from "react";
import { OnlineShopping } from "./OnlineShopping";

function App() {
  return (
    <div className="App">
      <OnlineShopping />
    </div>
  );
}

export default App;
